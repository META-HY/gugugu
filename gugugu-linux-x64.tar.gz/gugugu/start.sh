#!/bin/sh
# 咕咕咕 · Linux 前台启动（调试 / 无 systemd 环境使用）
# 用法：解压后进入本目录，执行  sh start.sh（或 chmod +x start.sh && ./start.sh）
# 要求：Node.js >= 20.9
# 端口默认 47890，监听 0.0.0.0；端口可用环境变量覆盖：PORT=80 sh start.sh
# 生产部署推荐：sudo sh install.sh —— 注册 systemd 服务（开机自启 + 崩溃自动重启）
cd "$(dirname "$0")"
export PORT="${PORT:-47890}"
export HOSTNAME="0.0.0.0"
exec node server.js
