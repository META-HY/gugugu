// 咕咕咕 · pm2 进程守护配置（适用于无 systemd 的环境，如部分容器）
// 安装：npm i -g pm2 && pm2 start ecosystem.config.js
// 开机自启：pm2 save && pm2 startup（按提示执行输出的命令）
// 常用：pm2 logs gugugu | pm2 restart gugugu | pm2 stop gugugu
module.exports = {
  apps: [
    {
      name: 'gugugu',
      script: 'server.js',
      cwd: __dirname,
      env: {
        NODE_ENV: 'production',
        PORT: process.env.PORT || 47890,
        HOSTNAME: '0.0.0.0',
      },
      // 崩溃后 3 秒自动重启
      autorestart: true,
      restart_delay: 3000,
      // 常驻内存超限自我回收（standalone 模式常态 ~150MB）
      max_memory_restart: '500M',
    },
  ],
};
