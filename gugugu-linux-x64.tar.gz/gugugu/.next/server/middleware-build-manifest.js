globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/3fefOHX2WXqjlF5IjPYFm/_buildManifest.js",
    "static/3fefOHX2WXqjlF5IjPYFm/_ssgManifest.js",
    "static/3fefOHX2WXqjlF5IjPYFm/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1jexzsn2qdw84.js",
    "static/chunks/2ey_icn33wsjp.js",
    "static/chunks/0u_wtdc9-d3f1.js",
    "static/chunks/0-4srap-ffvu1.js",
    "static/chunks/1guwmpcc-9wgo.js",
    "static/chunks/turbopack-1tze6aph1klyd.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
