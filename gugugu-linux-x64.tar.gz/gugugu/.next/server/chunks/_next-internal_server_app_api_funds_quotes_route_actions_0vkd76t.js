module.exports=[836107,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_quotes_route_actions_0vkd76t.js.map