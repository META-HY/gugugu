module.exports=[206052,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_industries_route_actions_0utymzu.js.map