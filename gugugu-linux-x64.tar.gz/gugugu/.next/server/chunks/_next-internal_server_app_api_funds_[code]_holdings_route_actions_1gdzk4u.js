module.exports=[612750,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_%5Bcode%5D_holdings_route_actions_1gdzk4u.js.map