module.exports=[879938,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_indices_%5Bcode%5D_trend_route_actions_1btg3wj.js.map