module.exports=[25321,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_%5Bcode%5D_history_route_actions_0cz-2-6.js.map