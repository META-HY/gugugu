module.exports=[768196,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_search_route_actions_1rydwcb.js.map