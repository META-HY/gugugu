module.exports=[315517,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_%5Bcode%5D_detail_route_actions_029tiit.js.map