module.exports=[665121,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fund_%5Bcode%5D_page_actions_203dzvk.js.map