module.exports=[152081,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_funds_page_actions_1ni-0ak.js.map