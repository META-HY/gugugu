module.exports=[21753,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_indices_route_actions_1v0gn02.js.map