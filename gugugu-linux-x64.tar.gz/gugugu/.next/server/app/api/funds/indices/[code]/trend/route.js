var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/indices/[code]/trend/route.js")
R.c("server/chunks/[root-of-the-server]__1fctrfz._.js")
R.c("server/chunks/[root-of-the-server]__0xvmezr._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_indices_[code]_trend_route_actions_1btg3wj.js")
R.m(839904)
module.exports=R.m(839904).exports
