var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/indices/route.js")
R.c("server/chunks/[root-of-the-server]__12lydkb._.js")
R.c("server/chunks/[root-of-the-server]__0xvmezr._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_indices_route_actions_1v0gn02.js")
R.m(336314)
module.exports=R.m(336314).exports
