var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/[code]/history/route.js")
R.c("server/chunks/[root-of-the-server]__1aps6o-._.js")
R.c("server/chunks/[root-of-the-server]__0xvmezr._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_[code]_history_route_actions_0cz-2-6.js")
R.m(434303)
module.exports=R.m(434303).exports
