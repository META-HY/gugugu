var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/[code]/intraday/route.js")
R.c("server/chunks/[root-of-the-server]__1_32mvn._.js")
R.c("server/chunks/[root-of-the-server]__0xvmezr._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_[code]_intraday_route_actions_1jo3ry5.js")
R.m(27852)
module.exports=R.m(27852).exports
