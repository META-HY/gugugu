var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/[code]/holdings/route.js")
R.c("server/chunks/[root-of-the-server]__0220kw0._.js")
R.c("server/chunks/[root-of-the-server]__0xvmezr._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_[code]_holdings_route_actions_1gdzk4u.js")
R.m(974022)
module.exports=R.m(974022).exports
