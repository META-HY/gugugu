var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/[code]/detail/route.js")
R.c("server/chunks/[root-of-the-server]__07sb0vr._.js")
R.c("server/chunks/[root-of-the-server]__0xvmezr._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_[code]_detail_route_actions_029tiit.js")
R.m(902828)
module.exports=R.m(902828).exports
