var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/quotes/route.js")
R.c("server/chunks/[root-of-the-server]__0p13iqp._.js")
R.c("server/chunks/[root-of-the-server]__0xvmezr._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_quotes_route_actions_0vkd76t.js")
R.m(710999)
module.exports=R.m(710999).exports
