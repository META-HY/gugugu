var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/industries/route.js")
R.c("server/chunks/[root-of-the-server]__1rjydp1._.js")
R.c("server/chunks/[root-of-the-server]__0xvmezr._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_industries_route_actions_0utymzu.js")
R.m(407143)
module.exports=R.m(407143).exports
