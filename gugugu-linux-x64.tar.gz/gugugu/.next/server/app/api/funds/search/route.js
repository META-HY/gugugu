var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/search/route.js")
R.c("server/chunks/[root-of-the-server]__1fdo3rw._.js")
R.c("server/chunks/[root-of-the-server]__0xvmezr._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_search_route_actions_1rydwcb.js")
R.m(391808)
module.exports=R.m(391808).exports
