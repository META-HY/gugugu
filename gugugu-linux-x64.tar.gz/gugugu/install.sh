#!/bin/sh
# 咕咕咕 · 一键安装为 systemd 服务（开机自启 + 崩溃自动重启）
# 用法：解压后进入本目录，执行：sudo sh install.sh [端口]   （默认 47890）
# 卸载：sudo systemctl disable --now gugugu && sudo rm /etc/systemd/system/gugugu.service
set -e
cd "$(dirname "$0")"
APP_DIR=$(pwd)
PORT="${1:-47890}"
SUDO=""
[ "$(id -u)" = "0" ] || SUDO="sudo"

# --- Node.js 环境检查（Next.js 16 要求 >= 20.9）---
if ! command -v node >/dev/null 2>&1; then
  echo "错误：未检测到 Node.js，请先安装 Node.js >= 20.9"
  exit 1
fi
if ! node -e 'const[m,n]=process.versions.node.split(".").map(Number);process.exit(m>20||(m===20&&n>=9)?0:1)'; then
  echo "错误：Node.js 版本过低（当前 $(node -v)，需要 >= 20.9）"
  exit 1
fi

# --- systemd 环境：注册系统服务 ---
if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
  # 以实际调用者身份运行（sudo 安装时不切 root，避免 nvm 等用户级 Node 不可读）
  RUN_USER="${SUDO_USER:-$(id -un)}"
  # 解析 node 绝对路径写入 ExecStart：systemd 无用户 PATH，nvm 安装的 node 也找得到
  NODE_BIN=$(command -v node)
  sed -e "s|__APP_DIR__|$APP_DIR|g" \
      -e "s|__NODE__|$NODE_BIN|g" \
      -e "s|__PORT__|$PORT|g" \
      -e "s|__USER__|$RUN_USER|g" \
      gugugu.service | $SUDO tee /etc/systemd/system/gugugu.service >/dev/null
  $SUDO systemctl daemon-reload
  $SUDO systemctl enable gugugu >/dev/null 2>&1
  $SUDO systemctl restart gugugu
  sleep 1
  if $SUDO systemctl is-active --quiet gugugu; then
    echo "安装完成：gugugu 已运行并设为开机自启（端口 $PORT，目录 $APP_DIR）"
  else
    echo "警告：服务未进入运行态，排查：journalctl -u gugugu -n 50 --no-pager"
  fi
  echo "  状态:   systemctl status gugugu"
  echo "  日志:   journalctl -u gugugu -f"
  echo "  重启:   $SUDO systemctl restart gugugu"
  echo "  停止:   $SUDO systemctl stop gugugu"
else
  # --- 无 systemd（容器 / 精简系统）：给出替代方案 ---
  echo "未检测到 systemd，可改用："
  echo "  pm2 托管: npm i -g pm2 && pm2 start ecosystem.config.js && pm2 save && pm2 startup"
  echo "  前台运行: sh start.sh"
fi
